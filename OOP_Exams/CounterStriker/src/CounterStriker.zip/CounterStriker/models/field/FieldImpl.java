package CounterStriker.models.field;

import CounterStriker.models.players.CounterTerrorist;
import CounterStriker.models.players.Player;
import CounterStriker.models.players.Terrorist;
import org.w3c.dom.css.Counter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import static CounterStriker.common.OutputMessages.COUNTER_TERRORIST_WINS;
import static CounterStriker.common.OutputMessages.TERRORIST_WINS;

public class FieldImpl implements Field {

    @Override
    public String start(Collection<Player> players) {
        List<Player> terrorists = players
                .stream()
                .filter(p -> p instanceof Terrorist)
                .collect(Collectors.toList());
        List<Player> counterTerrorists = players
                .stream()
                .filter(p -> p instanceof CounterTerrorist)
                .collect(Collectors.toList());


        while (true) {
            for (Player terrorist : terrorists) {
                for (Player counterTerrorist : counterTerrorists) {
                    if (counterTerrorist.isAlive()) {
                        counterTerrorist.takeDamage(terrorist.getGun().fire());
                    }
                }
            }
            for (Player counterTerrorist : counterTerrorists) {
                for (Player terrorist : terrorists) {
                    if (terrorist.isAlive()) {
                        terrorist.takeDamage(counterTerrorist.getGun().fire());
                    }
                }
            }
            boolean allDeathT = true;
            boolean allDeathCT = true;
            for (Player terrorist : terrorists) {
                if (terrorist.isAlive()) {
                    allDeathT = false;
                    break;
                }
            }
            for (Player counterTerrorist : counterTerrorists) {
                if (counterTerrorist.isAlive()) {
                    allDeathCT = false;
                    break;
                }
            }
            if (allDeathCT) {
                return TERRORIST_WINS;
            }
            if (allDeathT) {
                return COUNTER_TERRORIST_WINS;
            }
        }
    }
}
