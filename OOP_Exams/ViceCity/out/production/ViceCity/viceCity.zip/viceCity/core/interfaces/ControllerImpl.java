package viceCity.core.interfaces;

import viceCity.common.ConstantMessages;
import viceCity.common.ExceptionMessages;
import viceCity.models.guns.Gun;
import viceCity.models.guns.Pistol;
import viceCity.models.guns.Rifle;
import viceCity.models.neighbourhood.GangNeighbourhood;
import viceCity.models.players.BasePlayer;
import viceCity.models.players.CivilPlayer;
import viceCity.models.players.MainPlayer;
import viceCity.models.players.Player;
import viceCity.repositories.interfaces.GunRepository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static viceCity.common.ConstantMessages.*;

public class ControllerImpl implements Controller {
    private MainPlayer mainPlayer;
    private Collection<Player> civilPlayers;
    private GunRepository gunRepository;
    private GangNeighbourhood gangNeighbourhood;

    public ControllerImpl() {
        this.mainPlayer = new MainPlayer();
        this.civilPlayers = new ArrayList<>();
        this.gunRepository = new GunRepository();
        this.gangNeighbourhood = new GangNeighbourhood();
    }

    @Override
    public String addPlayer(String name) {
        CivilPlayer civilPlayer = new CivilPlayer(name);
        this.civilPlayers.add(civilPlayer);
        return String.format(PLAYER_ADDED, name);
    }

    @Override
    public String addGun(String type, String name) {
        if (!type.equals("Pistol") && !type.equals("Rifle")) {
            throw new IllegalArgumentException(GUN_TYPE_INVALID);
        }
        switch (type) {
            case "Pistol":
                this.gunRepository.add(new Pistol(name));
                break;
            case "Rifle":
                this.gunRepository.add(new Rifle(name));
                break;
        }
        return String.format(GUN_ADDED, name, type);
    }

    @Override
    public String addGunToPlayer(String name) {
        if (gunRepository.getModels().isEmpty()) {
            throw new IllegalArgumentException(GUN_QUEUE_IS_EMPTY);
        }
        if (name.equals("Vercetti")) {
            for (Gun model : gunRepository.getModels()) {
                mainPlayer.getGunRepository().add(model);
                gunRepository.getModels().remove(model);
                return String.format(GUN_ADDED_TO_MAIN_PLAYER, model.getName(), mainPlayer.getName());
            }
        }
        if (civilPlayers.stream().noneMatch(e -> e.getName().equals(name))) {
            throw new IllegalArgumentException(CIVIL_PLAYER_DOES_NOT_EXIST);
        } else {
            for (Gun model : gunRepository.getModels()) {
                for (Player civilPlayer : civilPlayers) {
                    if (civilPlayer.getName().equals(name)) {
                        civilPlayer.getGunRepository().add(model);
                        gunRepository.getModels().remove(model);
                        return String.format(GUN_ADDED_TO_CIVIL_PLAYER, model.getName(), civilPlayer.getName());
                    }
                }
            }
        }
        return null;
    }

    @Override
    public String fight() {
        gangNeighbourhood.action(mainPlayer, civilPlayers);
        if (civilPlayers.stream().allMatch(p -> p.getLifePoints() == 50) && mainPlayer.getLifePoints() == 100) {
            return FIGHT_HOT_HAPPENED;
        }
        StringBuilder result = new StringBuilder(FIGHT_HAPPENED).append(System.lineSeparator());
        result.append(String.format(MAIN_PLAYER_LIVE_POINTS_MESSAGE, mainPlayer.getLifePoints())).append(System.lineSeparator());
        int civilDeath = 0;
        for (Player civilPlayer : civilPlayers) {
            if (!civilPlayer.isAlive()) {
                civilDeath++;
            }
        }
        result.append(String.format(MAIN_PLAYER_KILLED_CIVIL_PLAYERS_MESSAGE, civilDeath)).append(System.lineSeparator());
        result.append(String.format(CIVIL_PLAYERS_LEFT_MESSAGE, civilPlayers.size() - civilDeath));
        return result.toString().trim();
    }
}
