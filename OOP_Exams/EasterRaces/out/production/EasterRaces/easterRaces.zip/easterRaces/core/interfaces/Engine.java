package easterRaces.core.interfaces;

public interface Engine extends Runnable {
}
