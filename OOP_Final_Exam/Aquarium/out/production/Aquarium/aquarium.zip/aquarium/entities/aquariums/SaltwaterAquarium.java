package aquarium.entities.aquariums;

public class SaltwaterAquarium extends BaseAquarium{
    private final static int CAPACITY = 25;
    protected SaltwaterAquarium(String name) {
        super(name, CAPACITY);
    }
}
